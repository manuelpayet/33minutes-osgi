#!/bin/bash
#docker-machine ssh default docker exec -i karaf4test_karaf_1 //refresh.sh
touch /deploy/*.jar /opt/karaf/instances/child/deploy/*.jar